<?php


// Cek apakah user sudah login
if (empty($_SESSION['email']) || empty($_SESSION['nama'])) {
    echo "<script type='text/javascript'>
            alert('Anda Belum Login :) Silahkan Login terlebih dahulu!');
            window.location.href = 'login.php';
          </script>";
    exit();
}
?>
