<?php
include("../db/config.php");

// Ambil data profil
$result = mysqli_query($conn, "SELECT * FROM profil WHERE id_profil = '1'");
$zz = $result && mysqli_num_rows($result) > 0 ? mysqli_fetch_assoc($result) : [];
$namaprofil = $zz['namafutsal'] ?? 'Nama Futsal';
$alamatprofil = $zz['alamat'] ?? '';
$kodeposprofil = $zz['kodepos'] ?? '';
$faxprofil = $zz['fax'] ?? '';
$no_telponprofil = $zz['no_hp'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin | <?php echo htmlspecialchars($namaprofil); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap 5 & FontAwesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
:root {
    --primary-color: #ff69b4;   /* Hot Pink */
    --secondary-color: #ffe6f0; /* Pink muda */
    --text-color: #4a4a4a;
    --hover-color: #ff85c1;
}

/* Layout flex & sticky footer */
html, body { height: 100%; margin: 0; }
body { display: flex; flex-direction: column; background-color: var(--secondary-color); font-family: 'Segoe UI', sans-serif; color: var(--text-color); }
.main { flex: 1 0 auto; }

/* Navbar & Subnavbar */
.navbar, .subnavbar { background-color: var(--primary-color) !important; }
.navbar-brand { font-weight: bold; color: #fff !important; }
.subnavbar .nav-link { color: #fff; transition: background 0.3s, transform 0.2s; }
.subnavbar .nav-link:hover, .subnavbar .nav-link.active { background-color: var(--hover-color); border-radius: 8px; transform: scale(1.05); }

/* Widget bergaya & animasi */
.widget {
    background-color: #fff;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    margin-bottom: 25px;
    padding: 25px;
}

.widget-header h3 { color: var(--primary-color); font-weight: 600; margin-bottom: 15px; }

.big-stats-container img { border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }

/* Animasi fade-in dari bawah */
@keyframes fadeInUp {
    0% { opacity: 0; transform: translateY(20px); }
    100% { opacity: 1; transform: translateY(0); }
}

.animate-item {
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInUp 0.6s forwards;
}

.animate-item:nth-child(1) { animation-delay: 0.2s; }
.animate-item:nth-child(2) { animation-delay: 0.4s; }
.animate-item:nth-child(3) { animation-delay: 0.6s; }
.animate-item:nth-child(4) { animation-delay: 0.8s; }
.animate-item:nth-child(5) { animation-delay: 1s; }
.animate-item:nth-child(6) { animation-delay: 1.2s; }

/* Footer */
.application-footer {
    flex-shrink: 0;
    background-color: var(--primary-color);
    color: #fff;
    padding: 20px 0;
    text-align: center;
    font-size: 0.9rem;
}

a { text-decoration: none; }
</style>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-futbol"></i> Admin <?php echo htmlspecialchars($namaprofil); ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i> <?php echo $_SESSION['username'] ?? 'Guest'; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Subnavbar -->
<div class="subnavbar py-2 mt-5">
    <div class="container d-flex flex-wrap gap-2">
        <a href="index.php" class="nav-link active"><i class="fas fa-home"></i> Home</a>
        <a href="index.php?modul=pengunjung" class="nav-link"><i class="fas fa-users"></i> Data Pelanggan</a>
        <a href="index.php?modul=boking" class="nav-link"><i class="fas fa-list"></i> Pemesanan</a>
        <a href="index.php?modul=daftar_boking" class="nav-link"><i class="fas fa-list-alt"></i> Daftar Pemesanan</a>
        <a href="index.php?modul=admin" class="nav-link"><i class="fas fa-user-shield"></i> Data Admin</a>
        <a href="index.php?modul=profil" class="nav-link"><i class="fas fa-building"></i> Profil</a>
        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#"><i class="fas fa-print"></i> Laporan</a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="index.php?modul=laporanx"><b>Laporan Pemesanan & Keuangan</b></a></li>
        </ul>
    </div>
</div>

<!-- Main Content -->
<div class="main py-5">
    <div class="container">
        <?php
        if (!empty($_GET['modul']) && file_exists("modul/{$_GET['modul']}.php")) {
            include("modul/{$_GET['modul']}.php");
        } else {
        ?>
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="widget p-4">
                    <!-- Header Widget -->
                    <div class="widget-header animate-item">
                        <h3>Selamat Datang, Administrator!</h3>
                    </div>

                    <!-- Konten Widget -->
                    <div class="widget-content d-flex flex-wrap align-items-center justify-content-between">
                        <div class="text-start flex-grow-1">
                            <p class="animate-item">Selamat Datang di <b>Aplikasi Reservasi Lapangan Futsal <?php echo htmlspecialchars($namaprofil); ?></b>!</p>
                            <p class="animate-item"><i class="fas fa-map-marker-alt me-2"></i>Alamat: <?php echo htmlspecialchars($alamatprofil); ?></p>
                            <p class="animate-item"><i class="fas fa-envelope me-2"></i>Kode Pos: <?php echo htmlspecialchars($kodeposprofil); ?></p>
                            <p class="animate-item"><i class="fas fa-phone me-2"></i>Telp: <?php echo htmlspecialchars($no_telponprofil); ?></p>
                            <p class="animate-item"><i class="fas fa-fax me-2"></i>Fax: <?php echo htmlspecialchars($faxprofil); ?></p>
                        </div>
                        <div class="text-end flex-shrink-0 animate-item">
                            <img src="img/logo.jpg" alt="Logo" class="img-fluid rounded shadow-sm" width="180">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<!-- Footer -->
<footer class="application-footer">
    <div class="container">
        <p><b>Aplikasi Reservasi Lapangan Futsal</b></p>
        <p>All rights reserved. &copy; <?php echo htmlspecialchars($namaprofil); ?></p>
    </div>
</footer>

</body>
</html>
