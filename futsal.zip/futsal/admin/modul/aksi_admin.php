<?php
defined("VALIDASI") or die("Tidak Diperkenankan Mengakses Data Secara Langsung !");

// Mulai session


if (empty($_SESSION['username']) || empty($_SESSION['nama'])) {
    echo "<script>
            alert('Anda Belum Login :) , Silahkan Login terlebih dahulu');  
            window.location = 'login.php';  
          </script>";
    exit;
}


// Ambil modul dan aksi
$modul = $_GET['modul'] ?? '';
$act = $_GET['act'] ?? '';

// Koneksi database
$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Include fungsi upload (gunakan include_once agar tidak redeclare)
include_once "fungsigambar.php";

// ================= INPUT USER =================
if ($modul == 'aksi_admin' && $act == 'input_admin') {
    $username = $_POST['username'] ?? '';
    $password = md5($_POST['password'] ?? '');
    $nama     = $_POST['nama'] ?? '';
    $email    = $_POST['email'] ?? '';

    $lokasi_file = $_FILES['fupload']['tmp_name'] ?? '';
    $nama_file   = $_FILES['fupload']['name'] ?? '';
    $acak        = rand(1, 99);
    $nama_file_unik = $acak . $nama_file;

    if (!empty($lokasi_file)) {
        UploadImageUser($nama_file_unik);
    }

    // Cek username sudah ada
    $stmt = $conn->prepare("SELECT username FROM admin WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>
                alert('Data tidak berhasil ditambah, Username telah terpakai !! Coba Lagi');
                window.location.href='index.php?modul=admin';
              </script>";
        exit;
    }
    $stmt->close();

    // Insert data admin
    $stmt = $conn->prepare("INSERT INTO admin (username, password, nama, email, foto) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $password, $nama, $email, $nama_file_unik);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Data Telah Ditambahkan');
            window.location.href='index.php?modul=admin';
          </script>";
    exit;
}

// ================= UPDATE USER =================
elseif ($modul == 'aksi_admin' && $act == 'update_admin') {
    $id_admin = $_POST['kode'] ?? '';
    $username = $_POST['username'] ?? '';
    $nama     = $_POST['nama'] ?? '';
    $email    = $_POST['email'] ?? '';

    $lokasi_file = $_FILES['fupload']['tmp_name'] ?? '';

    // Jika tidak ada file baru
    if (empty($lokasi_file)) {
        $stmt = $conn->prepare("UPDATE admin SET username=?, nama=?, email=? WHERE id_admin=?");
        $stmt->bind_param("sssi", $username, $nama, $email, $id_admin);
        $stmt->execute();
        $stmt->close();

        echo "<script>
                alert('Data Telah Diubah');
                window.location.href='index.php?modul=admin';
              </script>";
    } else {
        // Jika ada file baru
        $nama_file = $_FILES['fupload']['name'];
        $acak = rand(1, 99);
        $nama_file_unik = $acak . $nama_file;

        // Hapus file lama
        $stmt = $conn->prepare("SELECT foto FROM admin WHERE id_admin=?");
        $stmt->bind_param("i", $id_admin);
        $stmt->execute();
        $stmt->bind_result($foto_lama);
        $stmt->fetch();
        $stmt->close();

        if ($foto_lama) {
            @unlink("../Gambar/Gambar_user/$foto_lama");
            @unlink("../Gambar/Gambar_user/small_$foto_lama");
        }

        UploadImageUser($nama_file_unik);

        $stmt = $conn->prepare("UPDATE admin SET username=?, nama=?, email=?, foto=? WHERE id_admin=?");
        $stmt->bind_param("ssssi", $username, $nama, $email, $nama_file_unik, $id_admin);
        $stmt->execute();
        $stmt->close();

        echo "<script>
                alert('Data dan Foto Telah Diubah');
                window.location.href='index.php?modul=admin';
              </script>";
    }
    exit;
}

// ================= HAPUS USER =================
elseif ($modul == 'aksi_admin' && $act == 'hapus_admin') {
    $id_admin = $_GET['id'] ?? '';

    // Ambil nama file lama
    $stmt = $conn->prepare("SELECT foto FROM admin WHERE id_admin=?");
    $stmt->bind_param("i", $id_admin);
    $stmt->execute();
    $stmt->bind_result($foto_lama);
    $stmt->fetch();
    $stmt->close();

    // Hapus file lama
    if ($foto_lama) {
        @unlink("../Gambar/Gambar_user/$foto_lama");
        @unlink("../Gambar/Gambar_user/small_$foto_lama");
    }

    // Hapus data admin
    $stmt = $conn->prepare("DELETE FROM admin WHERE id_admin=?");
    $stmt->bind_param("i", $id_admin);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Data Telah Dihapus');
            window.location.href='index.php?modul=admin';
          </script>";
    exit;
}

// ================= UPDATE PASSWORD =================
elseif ($modul == 'aksi_admin' && $act == 'update_admin_password') {
    $id_admin = $_POST['id_admin'] ?? '';
    $password = md5($_POST['password'] ?? '');

    $stmt = $conn->prepare("UPDATE admin SET password=? WHERE id_admin=?");
    $stmt->bind_param("si", $password, $id_admin);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Password User $id_admin Telah Diubah');
            window.location.href='index.php?modul=admin';
          </script>";
    exit;
}

$conn->close();
?>
