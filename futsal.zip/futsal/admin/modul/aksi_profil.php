<?php
// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data dari POST dengan validasi sederhana
$id       = $_POST['id'] ?? '';
$futsal   = $_POST['namafutsal'] ?? '';
$alamat   = $_POST['alamat'] ?? '';
$kodepos  = $_POST['kodepos'] ?? '';
$fax      = $_POST['fax'] ?? '';
$nohp     = $_POST['no_hp'] ?? '';

// Prepared statement untuk update profil
$stmt = $conn->prepare("UPDATE profil SET 
    namafutsal = ?, 
    alamat = ?, 
    kodepos = ?, 
    fax = ?, 
    no_hp = ? 
    WHERE id_profil = ?");
$stmt->bind_param("sssssi", $futsal, $alamat, $kodepos, $fax, $nohp, $id);

if ($stmt->execute()) {
    echo "<script>
        alert('Profil berhasil diupdate');
        window.location.href='index.php?modul=profil';
    </script>";
} else {
    echo "<script>
        alert('Terjadi kesalahan: ".$stmt->error."');
        window.location.href='index.php?modul=profil';
    </script>";
}

$stmt->close();
$conn->close();
?>
