<?php
// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data POST dengan validasi sederhana
$id_laps    = $_POST['id_laps'] ?? '';
$username   = $_POST['username'] ?? '';
$idadmin    = $_POST['idadmin'] ?? '';
$idpelanggan= $_POST['iduser'] ?? '';
$idharga    = $_POST['idharga'] ?? '';
$password   = md5($_POST['password'] ?? '');
$nama       = $_POST['nama'] ?? '';
$email      = $_POST['email'] ?? '';
$nama_klub  = $_POST['nama_klub'] ?? '';
$tanggal    = $_POST['tanggals'] ?? '';
$jam        = $_POST['jams'] ?? '';
$harga      = $_POST['harga'] ?? 0;
$alamat     = $_POST['alamat'] ?? '';
$dp         = $_POST['dp'] ?? 0;
$sisa       = $_POST['sisa'] ?? 0;
$no_telpon  = $_POST['no_telpon'] ?? '';

// Cek apakah username sudah ada
$stmt_check = $conn->prepare("SELECT * FROM pelanggan WHERE username=?");
$stmt_check->bind_param("s", $username);
$stmt_check->execute();
$result_check = $stmt_check->get_result();
$pelanggan_exists = $result_check->num_rows > 0;

// Hitung status pembayaran
$status = ($dp + $sisa >= $harga) ? 'Lunas' : 'Pending';

// Insert ke tabel pemesanan
$stmt_pesan = $conn->prepare("INSERT INTO pemesanan
    (id_admin,id_pelanggan,id_harga,id_jadwal,username,nama_klub,alamat,no_telpon,tanggal,jam,harga,dp,sisa,status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
$stmt_pesan->bind_param("iiiissssssddds", $idadmin, $idpelanggan, $idharga, $id_laps, $username, $nama_klub, $alamat, $no_telpon, $tanggal, $jam, $harga, $dp, $sisa, $status);
$stmt_pesan->execute();

// Jika username belum ada, insert ke tabel pelanggan
if (!$pelanggan_exists) {
    $stmt_user = $conn->prepare("INSERT INTO pelanggan (username,password,nama,nama_klub,email,alamat,no_telpon) VALUES (?,?,?,?,?,?,?)");
    $stmt_user->bind_param("sssssss", $username, $password, $nama, $nama_klub, $email, $alamat, $no_telpon);
    $stmt_user->execute();
}

echo "<script>
    alert('Pemesanan sudah terkirim');
    window.location.href='index.php?modul=daftar_boking';
</script>";

// Tutup koneksi dan statement
$stmt_pesan->close();
if (isset($stmt_user)) $stmt_user->close();
$stmt_check->close();
$conn->close();
?>
