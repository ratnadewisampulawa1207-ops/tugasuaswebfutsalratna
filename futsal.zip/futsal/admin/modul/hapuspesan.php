<?php
include("../db/config.php"); // pastikan koneksi $conn tersedia

// Ambil ID dari GET dan pastikan integer
$id_pemesanan = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id_pemesanan > 0) {
    $stmt = $conn->prepare("DELETE FROM pemesanan WHERE id_pemesanan = ?");
    $stmt->bind_param("i", $id_pemesanan);

    if ($stmt->execute()) {
        echo "<script>
            alert('Data Telah dihapus');
            window.location.href='index.php?modul=pesananbaru';
        </script>";
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "<script>
        alert('ID pemesanan tidak valid!');
        window.location.href='index.php?modul=pesananbaru';
    </script>";
}

$conn->close();
?>
