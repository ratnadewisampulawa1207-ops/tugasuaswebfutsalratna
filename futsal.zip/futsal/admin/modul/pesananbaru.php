<?php
include("../db/config.php"); // pastikan path benar

$no = 0;
$sql = mysqli_query($conn, "SELECT * FROM pemesanan WHERE status='Tertunda' ORDER BY tanggal DESC");
?>

<div class="container my-5">
    <!-- Info Alert -->
    <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
        <h5 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> Info!</h5>
        <p>Harap konfirmasi pemesanan lapangan kepada pelanggan melalui SMS atau telepon kepada pihak yang memesan lapangan futsal.</p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    <!-- Daftar Pemesanan Baru -->
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-list"></i> Daftar Pemesanan Baru</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="pesan" class="table table-striped table-hover align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No.</th> 
                            <th>Username</th>
                            <th>Nama Klub</th> 
                            <th>Tanggal Main</th>
                            <th>Jam Main</th>
                            <th>No Telpon</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($cc = mysqli_fetch_assoc($sql)): $no++; ?>
                        <tr class="text-center">
                            <td><?php echo $no; ?></td>
                            <td><?php echo htmlspecialchars($cc['username']); ?></td>
                            <td><?php echo htmlspecialchars($cc['nama_klub']); ?></td>
                            <td><?php echo htmlspecialchars($cc['tanggal']); ?></td>
                            <td><?php echo htmlspecialchars($cc['jam']); ?></td>
                            <td><?php echo htmlspecialchars($cc['no_telpon']); ?></td>
                            <td>
                                <a href="index.php?modul=updatepesan&id=<?php echo $cc['id_pemesanan']; ?>" 
                                   onclick="return konfirmasix()" 
                                   class="btn btn-sm btn-success">
                                   <?php echo $cc['status']; ?>
                                </a>
                            </td>
                            <td class="d-flex gap-2 justify-content-center">
                                <a href="index.php?modul=updatepesan&id=<?php echo $cc['id_pemesanan']; ?>" 
                                   onclick="return konfirmasiz()" 
                                   class="btn btn-sm btn-warning"><i class="fas fa-check"></i> Konfirmasi</a>
                                <a href="index.php?modul=hapuspesan&id=<?php echo $cc['id_pemesanan']; ?>" 
                                   onclick="return konfirmasi()" 
                                   class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- JS Konfirmasi -->
<script type="text/javascript">
function konfirmasi() {
    return confirm("Anda yakin akan menghapus data ?");
}

function konfirmasiz() {
    return confirm("Dengan klik ini bahwa pelanggan bersangkutan benar-benar memesan lapangan futsal");
}

function konfirmasix() {
    return confirm("Dengan klik ini bahwa pelanggan bersangkutan sudah membayar lunas ?");
}

$(document).ready(function() {
    $('#pesan').DataTable({
        "scrollX": true,
        "language": {
            "lengthMenu": "Tampilkan _MENU_ data per halaman",
            "search": "Pencarian:",
            "zeroRecords": "Maaf, tidak ada data yang ditemukan",
            "info": "Menampilkan _START_ s/d _END_ dari _TOTAL_ data",
            "infoEmpty": "Menampilkan 0 s/d 0 dari 0 data",
            "infoFiltered": "(di filter dari _MAX_ total data)"
        }
    });
});
</script>
