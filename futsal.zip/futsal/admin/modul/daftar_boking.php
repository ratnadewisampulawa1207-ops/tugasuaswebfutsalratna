<?php
include '../db/config.php';

$no = 0;
$sql = $conn->query("SELECT * FROM pemesanan ORDER BY tanggal DESC");
?>

<script>
$(document).ready(function() {
    $('#pesan').DataTable();

    window.kd_k = 0;

    $(document).on("click", ".ubah", function () {
        var url = "modul/formbayar.php";
        kd_k = $(this).attr('id');
        $.post(url, {id: kd_k}, function(data) {
            $(".modal-body").html(data).show();
            $("#notifbayar").modal('show');
        });
    });

    $("#simpan-k").click(function(){
        var url = "index.php?modul=updatestatus";
        var v_dp = $('input:text[name=dp]').val();
        var v_sisa = $('input:text[name=sisa]').val();
        $.post(url, {dp: v_dp, sisa: v_sisa, id: kd_k}, function() {
            location.reload();
        });
    });
});

function konfirmasi(){
    return confirm("Anda yakin akan menghapus data ?");
}

function konfirmasix(){
    return confirm("Dengan klik ini bahwa pelanggan bersangkutan sudah membayar lunas ?");
}
</script>

<div class="main">
<div class="main-inner">
<div class="container">
    <div class="row">
        <div class="span11">
            <legend><b>Daftar Pemesanan</b></legend>
            <table id="pesan" class="display table table-striped">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Username</th>
                    <th>Nama Klub</th>
                    <th>Tanggal main</th>
                    <th>Jam Main</th>
                    <th>No Telpon</th>
                    <th>Status</th>
                    <th>DP</th>
                    <th>Sisa</th>
                    <th>AKSI</th>
                </tr>
            </thead>
            <tbody>
            <?php while($cc = $sql->fetch_assoc()): $no++; ?>
                <tr>
                    <td align="center"><?= $no ?></td>
                    <td align="center"><?= htmlspecialchars($cc['username']) ?></td>
                    <td align="center"><?= htmlspecialchars($cc['nama_klub']) ?></td>
                    <td align="center"><?= $cc['tanggal'] ?></td>
                    <td align="center"><?= $cc['jam'] ?></td>
                    <td align="center"><?= $cc['no_telpon'] ?></td>
                    <td align="center">
                        <?php if($cc['status'] == 'Pending'): ?>
                            <span class="btn btn-warning btn-sm">Pending</span>
                        <?php else: ?>
                            <span class="btn btn-success btn-sm">Lunas</span>
                        <?php endif; ?>
                    </td>
                    <td><?= !empty($cc['dp']) ? $cc['dp'] : "<span class='btn btn-success btn-sm'>-</span>" ?></td>
                    <td><?= !empty($cc['sisa']) ? $cc['sisa'] : "<span class='btn btn-success btn-sm'>-</span>" ?></td>
                    <td>
                        <?php if($cc['status'] == 'Pending'): ?>
                            <a href="modul/formbayar.php" id="<?= $cc['id_pemesanan'] ?>" class="ubah btn btn-success btn-sm">Bayar Pelunasan</a>
                            <a href="index.php?modul=hapus_pemesanan&id=<?= $cc['id_pemesanan'] ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm">Hapus</a>
                        <?php else: ?>
                            <span class="btn btn-success btn-sm">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>

<!-- Modal Bayar Pelunasan -->
<div class="modal fade" id="notifbayar" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Bayar Pelunasan</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input id="simpan-k" type="button" class="btn btn-warning" value="Bayar">
      </div>
    </div>
  </div>
</div>
