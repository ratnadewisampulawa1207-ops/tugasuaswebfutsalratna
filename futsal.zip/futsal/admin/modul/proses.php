<?php 
$id_lapangan = isset($_POST['id']) ? $_POST['id'] : '';
$tanggalz = isset($_POST['tanggalz']) ? $_POST['tanggalz'] : '';
$harga = isset($_POST['harga']) ? $_POST['harga'] : '';
$jam = isset($_POST['jamz']) ? $_POST['jamz'] : '';
$nama = isset($_POST['username']) ? $_POST['username'] : '';
$idku = isset($_POST['idku']) ? $_POST['idku'] : '';
$id_harga = isset($_POST['idharga']) ? $_POST['idharga'] : '';
?>

<script>
function sum() {
    let harga = parseInt(document.getElementById('txt1').value) || 0;
    let dp = parseInt(document.getElementById('txt2').value) || 0;
    let sisa = harga - dp;
    document.getElementById('txt3').value = sisa;
}

function checkInput(obj) {
    obj.value = obj.value.replace(/[^0-9]/g,'');
}
</script>

<div class="main">
    <div class="main-inner">
        <div class="container">
            <div class="row">

                <!-- Form Pemesanan -->
                <div class="col-md-5">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-primary text-white">
                            <b>Form Pemesanan</b>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="index.php?modul=aksi_proses" enctype="multipart/form-data">

                                <input type="hidden" name="idadmin" value="<?= $idku ?>">
                                <input type="hidden" name="idharga" value="<?= $id_harga ?>">

                                <div class="mb-3">
                                    <label class="form-label"><b>Id Jadwal</b></label>
                                    <input name="id_laps" class="form-control" value="<?= $id_lapangan ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Username</b></label>
                                    <input name="username" id="username" class="form-control" placeholder="Masukkan username">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Nama Lengkap</b></label>
                                    <input name="nama" id="nama" class="form-control" placeholder="Masukkan nama lengkap">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Email</b></label>
                                    <input name="email" id="email" class="form-control" placeholder="Masukkan email">
                                </div>

                                <div class="mb-3" id="ndelik">
                                    <label class="form-label"><b>Password</b></label>
                                    <input name="password" id="passwords" class="form-control" placeholder="Masukkan password">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Nama Klub</b></label>
                                    <input name="nama_klub" id="nama_klub" class="form-control" placeholder="Isi nama klub" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Tanggal</b></label>
                                    <input name="tanggals" class="form-control" value="<?= $tanggalz ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Jam Main</b></label>
                                    <input name="jams" class="form-control" value="<?= $jam ?>" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Harga</b></label>
                                    <input name="harga" class="form-control" value="<?= $harga ?>" id="txt1" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>DP</b></label>
                                    <input name="dp" class="form-control" id="txt2" placeholder="Isikan DP jika ada" onkeyup="sum();">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Sisa Pembayaran</b></label>
                                    <input name="sisa" class="form-control" id="txt3" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>Alamat</b></label>
                                    <textarea name="alamat" id="alamat" class="form-control" placeholder="Alamat lengkap" required></textarea>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><b>No Telpon</b></label>
                                    <input name="no_telpon" id="no_telpon" class="form-control" placeholder="Nomor telepon" maxlength="15" onkeyup="checkInput(this);" required>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-check-circle me-1"></i> Pesan
                                    </button>
                                    <a href="index.php?modul=boking" class="btn btn-secondary">
                                        <i class="fa fa-times me-1"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Info / Tips -->
                <div class="col-md-6">
                    <div class="alert alert-danger shadow-sm">
                        <b>Info!</b> Jika user sudah terdaftar, cukup masukkan username yang terdaftar. Biodata akan otomatis terisi dan password dikosongkan. Untuk user baru, isi semua form termasuk password.
                    </div>
                    <div class="alert alert-warning shadow-sm">
                        <b>Info!</b> Penyewa hanya dapat melakukan pemesanan sekali. Untuk ulang, hapus pemesanan melalui admin atau klik batal untuk mengulangi pemesanan sebelum submit.
                    </div>
                </div>

            </div><!-- /row -->
        </div><!-- /container -->
    </div><!-- /main-inner -->
</div><!-- /main -->
