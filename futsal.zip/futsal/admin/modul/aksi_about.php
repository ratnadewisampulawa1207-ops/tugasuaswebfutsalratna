<?php
$modul = $_GET['modul'] ?? '';
$act = $_GET['act'] ?? '';

$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if ($act == 'about') {
    $id12 = $_POST['id12'] ?? '';
    $about12 = $_POST['about'] ?? '';

    // Prepared statement untuk update
    $stmt = $conn->prepare("UPDATE about SET isi=? WHERE id_about=?");
    $stmt->bind_param("si", $about12, $id12);

    if ($stmt->execute()) {
        echo "<script>
                alert('Isi page About sudah diupdate');
                window.location.href='index.php?modul=profil';
              </script>";
    } else {
        echo "Gagal update: " . $stmt->error;
    }

    $stmt->close();

} elseif ($act == 'ketentuan') {
    $id21 = $_POST['id21'] ?? '';
    $ketentuan = $_POST['ketentuan'] ?? '';

    $stmt = $conn->prepare("UPDATE about SET isi=? WHERE id_about=?");
    $stmt->bind_param("si", $ketentuan, $id21);

    if ($stmt->execute()) {
        echo "<script>
                alert('Isi page Ketentuan sudah diupdate');
                window.location.href='index.php?modul=profil';
              </script>";
    } else {
        echo "Gagal update: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
