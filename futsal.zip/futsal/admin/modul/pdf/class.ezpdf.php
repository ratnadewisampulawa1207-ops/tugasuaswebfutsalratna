<?php
require('../fpdf/fpdf.php');
include '../db/config.php';

$tgl1 = $_POST['tgl1'] ?? '';
$tgl2 = $_POST['tgl2'] ?? '';

if (!$tgl1 || !$tgl2) {
    die("Tanggal belum diisi!");
}

$res = $conn->query("SELECT * FROM pemesanan WHERE tanggal BETWEEN '$tgl1' AND '$tgl2' ORDER BY tanggal ASC");

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Laporan Pemesanan Futsal',0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,7,'No',1);
$pdf->Cell(30,7,'Username',1);
$pdf->Cell(30,7,'Nama Klub',1);
$pdf->Cell(25,7,'Tanggal',1);
$pdf->Cell(20,7,'Jam',1);
$pdf->Cell(25,7,'Status',1);
$pdf->Cell(25,7,'DP',1);
$pdf->Cell(25,7,'Sisa',1);
$pdf->Ln();

$pdf->SetFont('Arial','',10);
$no=1;
while($row = $res->fetch_assoc()){
    $pdf->Cell(10,6,$no++,1);
    $pdf->Cell(30,6,$row['username'],1);
    $pdf->Cell(30,6,$row['nama_klub'],1);
    $pdf->Cell(25,6,$row['tanggal'],1);
    $pdf->Cell(20,6,$row['jam'],1);
    $pdf->Cell(25,6,$row['status'],1);
    $pdf->Cell(25,6,$row['dp'],1);
    $pdf->Cell(25,6,$row['sisa'],1);
    $pdf->Ln();
}

$pdf->Output();
