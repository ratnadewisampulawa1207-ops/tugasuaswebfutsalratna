<?php
include "../db/config.php";

// Ambil username dari parameter GET
$kode = $_GET['kode'] ?? '';

if ($kode != '') {
    // Gunakan prepared statement untuk keamanan
    $stmt = $conn->prepare("SELECT * FROM pelanggan WHERE username = ?");
    $stmt->bind_param("s", $kode);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        // Output data dalam format yang sama
        echo $row['id_pelanggan'] . "|" . $row['nama'] . "|" . $row['email'] . "|" . $row['nama_klub'] . "|" . $row['alamat'] . "|" . $row['no_telpon'];
    } else {
        echo "Data tidak ditemukan";
    }

    $stmt->close();
} else {
    echo "Username tidak valid";
}
?>
