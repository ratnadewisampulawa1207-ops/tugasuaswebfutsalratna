<script type="text/javascript"> 
function konfirmasi() {
    return confirm("Anda yakin akan menghapus data ?");
} 
</script>

<div class="main">
    <div class="main-inner">
        <div class="container">
            <div class="row">

                <!-- Form Tambah / Edit Admin -->
                <div class="col-md-3">
                    <?php 
                    switch ($_GET['act'] ?? null) {
                        default:
                    ?>
                    <legend><b>Tambah Data Admin</b></legend>
                    <form method="POST" action="index.php?modul=aksi_admin&act=input_admin" enctype="multipart/form-data">
                        <label><b>Username</b></label>
                        <input name="username" class="form-control" type="text" required>

                        <label><b>Password</b></label>
                        <input name="password" class="form-control" type="password" maxlength="80" required>

                        <label><b>Nama</b></label>
                        <input name="nama" class="form-control" type="text" required>

                        <label><b>Email</b></label>
                        <input name="email" class="form-control" type="email" required>

                        <label><b>Image</b></label>
                        <input name="fupload" class="form-control" type="file" required><br>

                        <input type="submit" class="btn btn-primary">
                        <input type="reset" class="btn btn-secondary">
                    </form>
                    <?php 
                        break;
                        case "edit":
                            $id_admin = $_GET['id'];
                            $stmt = $conn->prepare("SELECT * FROM admin WHERE id_admin = ?");
                            $stmt->bind_param("i", $id_admin);
                            $stmt->execute();
                            $data = $stmt->get_result()->fetch_assoc();
                    ?>
                    <legend><b>Edit Data Admin</b></legend>
                    <form method="POST" action="index.php?modul=aksi_admin&act=update_admin" enctype="multipart/form-data">
                        <a href="#" data-toggle="modal" data-target="#notifpassword" data-id="<?php echo $data['id_admin']; ?>" class="btn btn-warning btn-sm">Ubah Password</a><br><br>

                        <label><b>Id Admin</b></label>
                        <input name="kode" class="form-control" value="<?php echo htmlspecialchars($data['id_admin']); ?>" type="text" readonly>

                        <label><b>Username</b></label>
                        <input name="username" class="form-control" value="<?php echo htmlspecialchars($data['username']); ?>" type="text" required>

                        <label><b>Nama</b></label>
                        <input name="nama" class="form-control" value="<?php echo htmlspecialchars($data['nama']); ?>" type="text" required>

                        <label><b>Email</b></label>
                        <input name="email" class="form-control" value="<?php echo htmlspecialchars($data['email']); ?>" type="email" required>

                        <label><b>Image</b></label>
                        <img src="../Gambar/Gambar_user/small_<?php echo htmlspecialchars($data['foto']); ?>" width="100"><br><br>

                        <label><b>Ganti Image</b></label>
                        <input name="fupload" class="form-control" type="file"><br>

                        <input type="submit" class="btn btn-primary">
                        <input type="reset" class="btn btn-secondary">
                    </form>
                    <?php } ?>
                </div>

                <!-- Table Data Admin -->
                <div class="col-md-9">
                    <legend><b>Data Administrator</b></legend>
                    <table id="datatables" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th> 
                                <th>Username</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        $sql = $conn->query("SELECT * FROM admin ORDER BY id_admin");
                        $no = 0;
                        while($baris = $sql->fetch_assoc()){
                            $no++;
                        ?>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo htmlspecialchars($baris['username']); ?></td>
                            <td><?php echo htmlspecialchars($baris['nama']); ?></td>
                            <td><?php echo htmlspecialchars($baris['email']); ?></td>
                            <td>
                                <?php
                                $foto = $baris['foto'] === "no picture" ? "../Gambar/Gambar_noimage/no_img.jpg" : "../Gambar/Gambar_user/small_".$baris['foto'];
                                ?>
                                <img src="<?php echo $foto; ?>" width="100">
                            </td>
                            <td>
                                <a href="index.php?modul=admin&act=edit&id=<?php echo $baris['id_admin']; ?>" class="btn btn-info btn-sm">Edit</a>
                                <a href="index.php?modul=aksi_admin&act=hapus_admin&id=<?php echo $baris['id_admin']; ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm">Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div><!-- /col-md-9 -->

            </div><!-- /row -->
        </div><!-- /container -->
    </div><!-- /main-inner -->
</div><!-- /main -->

<!-- Modal Ubah Password -->
<div class="modal fade" id="notifpassword" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Password Admin</h4>
      </div>
      <div class="modal-body">
        <form method="post" action="index.php?modul=aksi_admin&act=update_admin_password">
          <div class="form-group">
            <label>Id Admin</label>
            <input id="idUser" name="id_admin" class="form-control" readonly>
            <label>Password Baru</label>
            <input name="password" class="form-control" type="password" required>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-warning" value="Update Password">
        </form>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$('#notifpassword').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Tombol yang men-trigger modal
    var id_admin = button.data('id'); // Ambil data-id
    $('#idUser', this).val(id_admin);
});
</script>
