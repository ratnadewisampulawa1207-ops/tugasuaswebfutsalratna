<?php
// Ambil tanggal dari POST, default hari ini
$tanggal = isset($_POST['tgl']) ? $_POST['tgl'] : date("Y-m-d");
$tanggal_safe = $conn->real_escape_string($tanggal);

// Ambil jadwal dan harga
$sql = "SELECT jadwal.id_jadwal, jadwal.jam, jadwal.jams, harga.harga, harga.id_harga
        FROM jadwal
        JOIN harga ON jadwal.id_harga = harga.id_harga
        ORDER BY jadwal.id_jadwal ASC";

$result = $conn->query($sql);
?>

<div class="table-responsive mt-4">
    <table class="table table-striped table-hover align-middle">
        <thead class="table-dark">
            <tr>
                <th>Jam</th>
                <th>Harga</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while($b = $result->fetch_assoc()): 
                $id_jadwal = $b['id_jadwal'];
                // Cek pemesanan
                $querys = "SELECT pemesanan.id_jadwal, pemesanan.status, pemesanan.tanggal 
                           FROM pemesanan
                           WHERE pemesanan.tanggal='$tanggal_safe' AND pemesanan.id_jadwal='$id_jadwal'";
                $res2 = $conn->query($querys);
                $z = $res2->fetch_assoc();
            ?>
            <tr>
                <td><i class="fa fa-clock me-2"></i><?php echo $b['jams']; ?></td>
                <td><i class="fa fa-money-bill-wave me-2"></i>Rp <?php echo number_format($b['harga'],0,",","."); ?></td>
                <td>
                    <?php if(isset($z['status']) && $z['status'] == 'Tertunda'): ?>
                        <form action="index.php?modul=proses" method="POST" class="d-inline">
                            <input type="hidden" name="username" value="<?php echo $_SESSION['namakamu']; ?>">
                            <input type="hidden" name="idku" value="<?php echo $_SESSION['id_admin']; ?>">
                            <input type="hidden" name="idharga" value="<?php echo $b['id_harga']; ?>">
                            <input type="hidden" name="id" value="<?php echo $id_jadwal; ?>">
                            <input type="hidden" name="tanggalz" value="<?php echo $tanggal_safe; ?>">
                            <input type="hidden" name="harga" value="<?php echo $b['harga']; ?>">
                            <input type="hidden" name="jamz" value="<?php echo $b['jams']; ?>">
                            <button type="submit" class="btn btn-warning btn-sm">
                                <i class="fa fa-hourglass-half me-1"></i> Pending
                            </button>
                        </form>
                    <?php elseif(isset($z['tanggal']) && $z['tanggal'] == $tanggal_safe): ?>
                        <button type="button" class="btn btn-danger btn-sm" disabled>
                            <i class="fa fa-ban me-1"></i> Booked
                        </button>
                    <?php else: ?>
                        <form action="index.php?modul=proses" method="POST" class="d-inline">
                            <input type="hidden" name="username" value="<?php echo $_SESSION['namakamu']; ?>">
                            <input type="hidden" name="idku" value="<?php echo $_SESSION['id_admin']; ?>">
                            <input type="hidden" name="idharga" value="<?php echo $b['id_harga']; ?>">
                            <input type="hidden" name="id" value="<?php echo $id_jadwal; ?>">
                            <input type="hidden" name="tanggalz" value="<?php echo $tanggal_safe; ?>">
                            <input type="hidden" name="harga" value="<?php echo $b['harga']; ?>">
                            <input type="hidden" name="jamz" value="<?php echo $b['jams']; ?>">
                            <button type="submit" class="btn btn-success btn-sm">
                                <i class="fa fa-check-circle me-1"></i> Pesan
                            </button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
$(document).ready(function () {
    // Datepicker Bootstrap + jQuery UI
    var date = new Date();
    $('#datepicker').datepicker({
        minDate: date,
        dateFormat: 'yy-mm-dd'
    });

    // Tooltip popover
    $('[data-bs-toggle="tooltip"]').tooltip();
});
</script>
