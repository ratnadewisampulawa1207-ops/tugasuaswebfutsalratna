<?php
include("../db/config.php"); // pastikan koneksi $conn tersedia

// Ambil ID dari URL
$kd_k = $_GET['id'] ?? '';

if ($kd_k != '') {
    // Gunakan prepared statement untuk keamanan
    $stmt = $conn->prepare("UPDATE pemesanan SET status='Pending' WHERE id_pemesanan=?");
    $stmt->bind_param("i", $kd_k);
    if ($stmt->execute()) {
        echo "<script>
            alert('Pemesanan sudah terkonfirmasi');
            window.location.href='index.php?modul=pesananbaru';
        </script>";
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "<script>
        alert('ID pemesanan tidak valid!');
        window.location.href='index.php?modul=pesananbaru';
    </script>";
}
?>
