<?php
session_start(); // HARUS BARIS PERTAMA
defined("VALIDASI") or die("Tidak Diperkenankan Mengakses Data Secara Langsung !");

// Cek session login
if (empty($_SESSION['username']) && empty($_SESSION['nama'])) {
    echo "<script>
        alert('Anda Belum Login :) , Silahkan Login terlebih dahulu');  
        window.location = 'login.php';  
    </script>";
    exit;
}

// Koneksi database
$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) die("Koneksi gagal: " . mysqli_connect_error());

// ========================
// INPUT PENGUNJUNG
// ========================
if ($_GET['modul'] == 'aksi_pengunjung' && $_GET['act'] == 'input_pengunjung') {
    $passwordz = md5($_POST['password']);
    $stmt = $conn->prepare("INSERT INTO pelanggan (username, password, nama, nama_klub, email, alamat, no_telpon) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $_POST['username'], $passwordz, $_POST['nama'], $_POST['nama_klub'], $_POST['email'], $_POST['alamat'], $_POST['no_telpon']);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Data Telah Ditambahkan'); window.location.href='index.php?modul=pengunjung';</script>";
    exit;
}

// ========================
// UPDATE PENGUNJUNG
// ========================
elseif ($_GET['modul'] == 'aksi_pengunjung' && $_GET['act'] == 'update_pengunjung') {
    $stmt = $conn->prepare("UPDATE pelanggan SET username=?, nama=?, nama_klub=?, email=?, alamat=?, no_telpon=? WHERE id_pelanggan=?");
    $stmt->bind_param("ssssssi", $_POST['username'], $_POST['nama'], $_POST['nama_klub'], $_POST['email'], $_POST['alamat'], $_POST['no_telpon'], $_POST['kode']);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Data Pelanggan Telah Diubah'); window.location.href='index.php?modul=pengunjung';</script>";
    exit;
}

// ========================
// HAPUS PENGUNJUNG
// ========================
elseif ($_GET['modul'] == 'aksi_pengunjung' && $_GET['act'] == 'hapus_pengunjung') {
    $stmt = $conn->prepare("DELETE FROM pelanggan WHERE id_pelanggan=?");
    $stmt->bind_param("i", $_GET['id']);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Data Telah Dihapus'); window.location.href='index.php?modul=pengunjung';</script>";
    exit;
}

// ========================
// UPDATE PASSWORD
// ========================
elseif ($_GET['modul'] == 'aksi_pengunjung' && $_GET['act'] == 'update_pengunjung_password') {
    $id_pengunjung = $_POST['id_user'];
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("UPDATE pelanggan SET password=? WHERE id_pelanggan=?");
    $stmt->bind_param("si", $password, $id_pengunjung);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Password Pelanggan Telah Diubah'); window.location.href='index.php?modul=pengunjung';</script>";
    exit;
}

$conn->close();
?>
