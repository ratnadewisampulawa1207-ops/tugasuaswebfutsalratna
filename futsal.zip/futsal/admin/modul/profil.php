<?php 
$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data profil
$angkas = 1;
$pp = $conn->query("SELECT * FROM profil WHERE id_profil='$angkas'");
$rr = $pp->fetch_assoc();
?>

<script type="text/javascript">
function konfirmasi() {
    return confirm("Anda yakin akan menghapus data?");
}

function checkInput(obj, pattern) {
    let rx = new RegExp(pattern);
    if (!obj.value.match(rx)) {
        obj.value = obj.lastMatched || "";
    } else {
        obj.lastMatched = obj.value;
    }
}
</script>

<div class="container my-5">
    <div class="row g-4">
        <!-- Profil -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Profil</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="index.php?modul=aksi_profil" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $rr['id_profil'] ?>">

                        <div class="mb-3">
                            <label class="form-label"><b>Nama Futsal</b></label>
                            <input name="namafutsal" class="form-control" value="<?= $rr['namafutsal'] ?>" type="text" maxlength="100"
                                   onkeyup="checkInput(this, '^[a-zA-Z ]*$');" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><b>Alamat</b></label>
                            <textarea name="alamat" class="form-control" rows="3" required><?= $rr['alamat'] ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><b>Kodepos</b></label>
                            <input name="kodepos" class="form-control" value="<?= $rr['kodepos'] ?>" type="tel" maxlength="15" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><b>No. Telpon</b></label>
                            <input name="no_hp" class="form-control" value="<?= $rr['no_hp'] ?>" type="tel" maxlength="15"
                                   onkeyup="checkInput(this, '^[0-9]*$');" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><b>Fax</b></label>
                            <input name="fax" class="form-control" value="<?= $rr['fax'] ?>" type="tel" maxlength="15" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Profil</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Harga -->
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Harga Jam Siang</h5>
                </div>
                <div class="card-body">
                    <?php
                    $id1 = 1;
                    $jmsiang = $conn->query("SELECT id_harga,harga FROM harga WHERE id_harga='$id1'");
                    $bacasiang = $jmsiang->fetch_assoc();
                    ?>
                    <form method="POST" action="index.php?modul=aksi_jam&act=day">
                        <input type="hidden" name="id1" value="<?= $bacasiang['id_harga'] ?>">
                        <div class="mb-3">
                            <label class="form-label"><b>Harga</b></label>
                            <input name="harga1" class="form-control" value="<?= $bacasiang['harga'] ?>" type="text" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Jam Siang</button>
                    </form>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Harga Jam Malam</h5>
                </div>
                <div class="card-body">
                    <?php
                    $id2 = 2;
                    $jmnight = $conn->query("SELECT id_harga,harga FROM harga WHERE id_harga='$id2'");
                    $bacanight = $jmnight->fetch_assoc();
                    ?>
                    <form method="POST" action="index.php?modul=aksi_jam&act=night">
                        <input type="hidden" name="id2" value="<?= $bacanight['id_harga'] ?>">
                        <div class="mb-3">
                            <label class="form-label"><b>Harga</b></label>
                            <input name="harga2" class="form-control" value="<?= $bacanight['harga'] ?>" type="text" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Jam Malam</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- About & Ketentuan -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">About</h5>
                </div>
                <div class="card-body">
                    <?php
                    $id12 = 1;
                    $aabout = $conn->query("SELECT id_about, isi FROM about WHERE id_about='$id12'");
                    $bacaabout = $aabout->fetch_assoc();
                    ?>
                    <form method="POST" action="index.php?modul=aksi_about&act=about">
                        <input type="hidden" name="id12" value="<?= $bacaabout['id_about'] ?>">
                        <div class="mb-3">
                            <textarea name="about" class="form-control ckeditor" rows="6"><?= $bacaabout['isi'] ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update About</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Ketentuan Pemakaian Lapangan</h5>
                </div>
                <div class="card-body">
                    <?php
                    $id21 = 2;
                    $aketentuan = $conn->query("SELECT id_about, isi FROM about WHERE id_about='$id21'");
                    $bacaketentuan = $aketentuan->fetch_assoc();
                    ?>
                    <form method="POST" action="index.php?modul=aksi_about&act=ketentuan">
                        <input type="hidden" name="id21" value="<?= $bacaketentuan['id_about'] ?>">
                        <div class="mb-3">
                            <textarea name="ketentuan" class="form-control ckeditor" rows="6"><?= $bacaketentuan['isi'] ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Ketentuan</button>
                    </form>
                </div>
            </div>
        </div>

    </div> <!-- /row -->
</div> <!-- /container -->
