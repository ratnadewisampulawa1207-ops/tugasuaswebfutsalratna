<?php
include '../db/config.php';

// Ambil filter tanggal dari form
$tgl1 = $_POST['tgl1'] ?? '';
$tgl2 = $_POST['tgl2'] ?? '';

$filter = "";
if ($tgl1 && $tgl2) {
    $filter = "WHERE tanggal BETWEEN '$tgl1' AND '$tgl2'";
}

$sql = $conn->query("SELECT * FROM pemesanan $filter ORDER BY tanggal DESC");
$no = 0;
?>

<script type="text/javascript">
$(document).ready(function() {
    $('#pesan').DataTable({
        "searching": false,
        "paging": false,
        "ordering": false,
        "info": false
    });
});

function konfirmasi() {
    return confirm("Anda yakin akan menghapus data?");
}
</script>

<div class="container my-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Daftar Pemesanan</h5>
                </div>
                <div class="card-body">

                    <!-- Form Filter Tanggal & Cetak Laporan -->
                    <form class="row g-3 align-items-center mb-3" action="" method="POST">
                        <div class="col-auto">
                            <label class="form-label"><b>Tanggal Awal</b></label>
                            <input type="date" class="form-control form-control-sm" name="tgl1" value="<?= $tgl1 ?>" required>
                        </div>

                        <div class="col-auto">
                            <label class="form-label"><b>Tanggal Akhir</b></label>
                            <input type="date" class="form-control form-control-sm" name="tgl2" value="<?= $tgl2 ?>" required>
                        </div>

                        <div class="col-auto mt-4">
                            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                        </div>

                        <div class="col-auto mt-4">
                            <button type="submit" formaction="modul/cetaklap.php" formtarget="_blank" class="btn btn-success btn-sm">Cetak PDF</button>
                        </div>
                    </form>

                    <!-- Table Daftar Pemesanan -->
                    <div class="table-responsive">
                        <table id="pesan" class="table table-bordered table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Username</th>
                                    <th>Nama Klub</th>
                                    <th>Tanggal Main</th>
                                    <th>Jam Main</th>
                                    <th>No Telpon</th>
                                    <th>Status</th>
                                    <th>DP</th>
                                    <th>Sisa</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($cc = $sql->fetch_assoc()): 
                                    $no++;
                                ?>
                                <tr>
                                    <td><?= $no ?></td>
                                    <td><?= htmlspecialchars($cc['username']) ?></td>
                                    <td><?= htmlspecialchars($cc['nama_klub']) ?></td>
                                    <td><?= $cc['tanggal'] ?></td>
                                    <td><?= $cc['jam'] ?></td>
                                    <td><?= $cc['no_telpon'] ?></td>
                                    <td>
                                        <?php if($cc['status']=='Pending'): ?>
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        <?php elseif($cc['status']=='Lunas'): ?>
                                            <span class="badge bg-success">Lunas</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= !empty($cc['dp']) ? $cc['dp'] : "<span class='text-muted'>-</span>" ?></td>
                                    <td><?= !empty($cc['sisa']) ? $cc['sisa'] : "<span class='text-muted'>-</span>" ?></td>
                                    <td>
                                        <?php if($cc['status']=='Pending'): ?>
                                            <a href="modul/formbayar.php" id="<?= $cc['id_pemesanan'] ?>" class="btn btn-success btn-sm" data-toggle="modal">Bayar Pelunasan</a>
                                            <a href="index.php?modul=hapus_pemesanan&id=<?= $cc['id_pemesanan'] ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm">Hapus</a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div> <!-- /table-responsive -->

                </div> <!-- /card-body -->
            </div> <!-- /card -->
        </div> <!-- /col-md-12 -->
    </div> <!-- /row -->
</div> <!-- /container -->
