<?php
include("../db/config.php"); // koneksi $conn

$kd_k = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if ($kd_k > 0) {
    $stmt = $conn->prepare("UPDATE pemesanan SET dp = 0, sisa = 0, status = 'Lunas' WHERE id_pemesanan = ?");
    $stmt->bind_param("i", $kd_k);

    if ($stmt->execute()) {
        echo "<script>
            alert('Pemesanan sudah dibayar');
            window.location.href='index.php?modul=daftar_boking';
        </script>";
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "<script>
        alert('ID pemesanan tidak valid!');
        window.location.href='index.php?modul=daftar_boking';
    </script>";
}

$conn->close();
?>
