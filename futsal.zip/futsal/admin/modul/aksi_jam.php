<?php
$modul = $_GET['modul'] ?? '';
$act = $_GET['act'] ?? '';

$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) die("Koneksi gagal: " . mysqli_connect_error());

// UPDATE HARGA SIANG
if ($act == 'day') {
    $id1 = $_POST['id1'] ?? '';
    $harga1 = $_POST['harga1'] ?? '';

    $stmt = $conn->prepare("UPDATE harga SET harga=? WHERE id_harga=?");
    $stmt->bind_param("di", $harga1, $id1); // d = double/decimal, i = integer
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Harga siang sudah diupdate');
            window.location.href='index.php?modul=profil';
          </script>";
    exit;
}

// UPDATE HARGA MALAM
elseif ($act == 'night') {
    $id2 = $_POST['id2'] ?? '';
    $harga2 = $_POST['harga2'] ?? '';

    $stmt = $conn->prepare("UPDATE harga SET harga=? WHERE id_harga=?");
    $stmt->bind_param("di", $harga2, $id2);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Harga malam sudah diupdate');
            window.location.href='index.php?modul=profil';
          </script>";
    exit;
}

$conn->close();
?>
