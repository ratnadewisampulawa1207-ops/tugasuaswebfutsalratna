<?php
defined("VALIDASI") or die("Tidak Diperkenankan Mengakses Data Secara Langsung !");


if (empty($_SESSION['username']) || empty($_SESSION['nama'])) {
    echo "<script>
            alert('Anda Belum Login :) , Silahkan Login terlebih dahulu');  
            window.location = 'login.php';  
          </script>";
    exit;
}


$modul = $_GET['modul'] ?? '';
$act = $_GET['act'] ?? '';

$conn = mysqli_connect("localhost", "root", "", "futsal");
if (!$conn) die("Koneksi gagal: " . mysqli_connect_error());

// Fungsi upload gambar (pastikan sudah didefinisikan)
function UploadImage($filename) {
    $target_dir = "../Gambar/Gambar_berita/";
    move_uploaded_file($_FILES['fupload']['tmp_name'], $target_dir . $filename);
}

// Fungsi slug (pastikan sudah ada)
function slug($text) {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9-]+/', '-', $text);
    return $text;
}

// INPUT BERITA
if ($modul == 'aksi_berita' && $act == 'input_berita') {
    $tgl_berita = $_POST['tgl_berita'] ?? '';
    $judul = $_POST['judul'] ?? '';
    $isi = $_POST['isi'] ?? '';
    $slug_berita = slug($judul);

    $lokasi_file = $_FILES['fupload']['tmp_name'] ?? '';
    $nama_file = $_FILES['fupload']['name'] ?? '';
    $acak = rand(1, 99);
    $nama_file_unik = $acak . $nama_file;

    if (!empty($lokasi_file)) {
        UploadImage($nama_file_unik);
    } else {
        $nama_file_unik = 'no picture';
    }

    $stmt = $conn->prepare("INSERT INTO berita (tgl_berita, judul, isi, foto, slug) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $tgl_berita, $judul, $isi, $nama_file_unik, $slug_berita);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Data Telah Ditambahkan');
            window.location.href='index.php?modul=berita';
          </script>";
    exit;
}

// UPDATE BERITA
elseif ($modul == 'aksi_berita' && $act == 'update_berita') {
    $id_berita = $_POST['kode'] ?? '';
    $tgl_berita = $_POST['tgl_berita'] ?? '';
    $judul = $_POST['judul'] ?? '';
    $isi = $_POST['isi'] ?? '';
    $slug_berita = slug($judul);

    $lokasi_file = $_FILES['fupload']['tmp_name'] ?? '';

    if (empty($lokasi_file)) {
        $stmt = $conn->prepare("UPDATE berita SET tgl_berita=?, judul=?, isi=?, slug=? WHERE id_berita=?");
        $stmt->bind_param("ssssi", $tgl_berita, $judul, $isi, $slug_berita, $id_berita);
        $stmt->execute();
        $stmt->close();

        echo "<script>
                alert('Data Telah Diubah');
                window.location.href='index.php?modul=berita';
              </script>";
    } else {
        $nama_file = $_FILES['fupload']['name'];
        $acak = rand(1, 99);
        $nama_file_unik = $acak . $nama_file;

        // Hapus file lama
        $stmt = $conn->prepare("SELECT foto FROM berita WHERE id_berita=?");
        $stmt->bind_param("i", $id_berita);
        $stmt->execute();
        $stmt->bind_result($foto_lama);
        $stmt->fetch();
        $stmt->close();

        if ($foto_lama && $foto_lama != 'no picture') {
            @unlink("../Gambar/Gambar_berita/$foto_lama");
            @unlink("../Gambar/Gambar_berita/small_$foto_lama");
        }

        UploadImage($nama_file_unik);

        $stmt = $conn->prepare("UPDATE berita SET tgl_berita=?, judul=?, isi=?, foto=?, slug=? WHERE id_berita=?");
        $stmt->bind_param("sssssi", $tgl_berita, $judul, $isi, $nama_file_unik, $slug_berita, $id_berita);
        $stmt->execute();
        $stmt->close();

        echo "<script>
                alert('Data dan Foto Telah Diubah');
                window.location.href='index.php?modul=berita';
              </script>";
    }
    exit;
}

// HAPUS BERITA
elseif ($modul == 'aksi_berita' && $act == 'hapus_berita') {
    $id_berita = $_GET['id'] ?? '';

    $stmt = $conn->prepare("SELECT foto FROM berita WHERE id_berita=?");
    $stmt->bind_param("i", $id_berita);
    $stmt->execute();
    $stmt->bind_result($foto_lama);
    $stmt->fetch();
    $stmt->close();

    if ($foto_lama && $foto_lama != 'no picture') {
        @unlink("../Gambar/Gambar_berita/$foto_lama");
        @unlink("../Gambar/Gambar_berita/small_$foto_lama");
    }

    $stmt = $conn->prepare("DELETE FROM berita WHERE id_berita=?");
    $stmt->bind_param("i", $id_berita);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Data Telah Dihapus');
            window.location.href='index.php?modul=berita';
          </script>";
    exit;
}

$conn->close();
?>
