<?php
include "../db/config.php"; // Pastikan $conn tersedia

function konfirmasi() {
    return confirm("Anda yakin akan menghapus data ?");
}
?>

<div class="container my-5">
    <div class="row g-4">
        <!-- Form Tambah/Edit Pelanggan -->
        <div class="col-lg-4">
            <?php 
            $act = $_GET['act'] ?? '';
            switch ($act) {
                default:
            ?>
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-user-plus"></i> Tambah Data Pelanggan</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="index.php?modul=aksi_pengunjung&act=input_pengunjung">
                        <div class="mb-3">
                            <label class="form-label"><b>Username</b></label>
                            <input name="username" type="text" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Password</b></label>
                            <input name="password" type="password" class="form-control" maxlength="80" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Nama Lengkap</b></label>
                            <input name="nama" type="text" class="form-control" maxlength="100" onKeyUp="checkInput2(this);" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Nama Klub</b></label>
                            <input name="nama_klub" type="text" class="form-control" maxlength="80" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Email</b></label>
                            <input name="email" type="email" class="form-control" maxlength="80" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Alamat</b></label>
                            <textarea name="alamat" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>No Telpon</b></label>
                            <input name="no_telpon" type="tel" class="form-control" maxlength="15" onKeyUp="checkInput(this);" required>
                        </div>
                        <button type="submit" class="btn btn-primary me-2"><i class="fas fa-save"></i> Simpan</button>
                        <button type="reset" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</button>
                    </form>
                </div>
            </div>
            <?php 
                break;

                case "edit":
                    $stmt = $conn->prepare("SELECT * FROM pelanggan WHERE id_pelanggan = ?");
                    $stmt->bind_param("i", $_GET['id']);
                    $stmt->execute();
                    $data = $stmt->get_result()->fetch_assoc();
                    $stmt->close();
            ?>
            <div class="card shadow-sm">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0"><i class="fas fa-edit"></i> Edit Data Pelanggan</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="index.php?modul=aksi_pengunjung&act=update_pengunjung">
                        <a href="<?php echo $data['id_pelanggan']; ?>" class="btn btn-info btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#notifpassword"><i class="fas fa-key"></i> Ubah Password</a>
                        <div class="mb-3">
                            <label class="form-label"><b>Id Pelanggan</b></label>
                            <input name="kode" value="<?php echo $data['id_pelanggan']; ?>" class="form-control" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Username</b></label>
                            <input name="username" value="<?php echo $data['username']; ?>" class="form-control" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Nama Lengkap</b></label>
                            <input name="nama" value="<?php echo $data['nama']; ?>" class="form-control" maxlength="100" onKeyUp="checkInput2(this);" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Nama Klub</b></label>
                            <input name="nama_klub" value="<?php echo $data['nama_klub']; ?>" class="form-control" maxlength="80" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Email</b></label>
                            <input name="email" value="<?php echo $data['email']; ?>" class="form-control" maxlength="80" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>Alamat</b></label>
                            <textarea name="alamat" class="form-control" rows="3" required><?php echo $data['alamat']; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><b>No Telpon</b></label>
                            <input name="no_telpon" value="<?php echo $data['no_telpon']; ?>" class="form-control" maxlength="15" onKeyUp="checkInput(this);" required>
                        </div>
                        <button type="submit" class="btn btn-warning me-2"><i class="fas fa-save"></i> Update</button>
                        <button type="reset" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</button>
                    </form>
                </div>
            </div>
            <?php
                break;
            }
            ?>
        </div>

        <!-- Tabel Data Pelanggan -->
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-users"></i> Data Pelanggan</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="datatables" class="table table-striped table-hover align-middle">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th>No.</th> 
                                    <th>Username</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>No Telpon</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            $no = 0;
                            $sql = $conn->query("SELECT * FROM pelanggan ORDER BY id_pelanggan");
                            while($baris = $sql->fetch_assoc()) { $no++; ?>
                                <tr class="text-center">
                                    <td><?php echo $no; ?></td>
                                    <td><?php echo $baris['username']; ?></td>
                                    <td><?php echo $baris['nama']; ?></td>
                                    <td><?php echo $baris['alamat']; ?></td>
                                    <td><?php echo $baris['no_telpon']; ?></td>
                                    <td class="d-flex gap-2 justify-content-center">
                                        <a href="index.php?modul=pengunjung&act=edit&id=<?php echo $baris['id_pelanggan']; ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                        <a href="index.php?modul=aksi_pengunjung&act=hapus_pengunjung&id=<?php echo $baris['id_pelanggan']; ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Hapus</a>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Password -->
<div class="modal fade" id="notifpassword" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content shadow">
      <div class="modal-header bg-warning">
        <h5 class="modal-title"><i class="fas fa-key"></i> Edit Password Pelanggan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" action="index.php?modul=aksi_pengunjung&act=update_pengunjung_password">
          <div class="mb-3">
            <label class="form-label"><b>Id Pelanggan</b></label>
            <input id="idUser" name="id_user" class="form-control" type="text" readonly>
          </div>
          <div class="mb-3">
            <label class="form-label"><b>Password Baru</b></label>
            <input name="password" class="form-control" type="password">
          </div>
          <div class="text-end">
            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-warning"><i class="fas fa-save"></i> Update Password</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
$('#notifpassword').on('show.bs.modal', function (event) {
    $('#idUser', this).val($(event.relatedTarget).attr('href'));
});

$(document).ready(function(){
    $('#datatables').DataTable({
        "scrollX": true,
        "language": {
            "lengthMenu": "Tampilkan _MENU_ data per halaman",
            "search": "Pencarian:",
            "zeroRecords": "Maaf, tidak ada data ditemukan",
            "info": "Menampilkan _START_ s/d _END_ dari _TOTAL_ data",
            "infoEmpty": "Menampilkan 0 s/d 0 dari 0 data",
            "infoFiltered": "(di filter dari _MAX_ total data)"
        }
    });
});

function checkInput2(obj) {
    obj.value = obj.value.replace(/[^a-zA-Z ]/g,'');
}
function checkInput(obj) {
    obj.value = obj.value.replace(/[^0-9]/g,'');
}
</script>
