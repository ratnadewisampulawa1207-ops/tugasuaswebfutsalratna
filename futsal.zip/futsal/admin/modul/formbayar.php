<?php
include "../db/config.php";

$kd_k = $_POST['id'] ?? 0;
if($kd_k == 0){
    echo "ID tidak valid!";
    exit;
}

// Gunakan mysqli dan prepared statement untuk keamanan
$stmt = $conn->prepare("SELECT * FROM pemesanan WHERE id_pemesanan = ?");
$stmt->bind_param("i", $kd_k);
$stmt->execute();
$result = $stmt->get_result();
$d = $result->fetch_assoc();
$stmt->close();

if(!$d){
    echo "Data tidak ditemukan!";
    exit;
}
?>

<form class="form" method="post" action="index.php?modul=updatestatus">
    <div class="form-group">
        <label class="control-label"><b>Id Pemesanan</b></label>
        <input id="idku" name="id" class="input-xxlarge form-control" value="<?= htmlspecialchars($d['id_pemesanan']) ?>" type="text" readonly>

        <label class="control-label"><b>Harga</b></label>
        <input name="harga" class="input-xxlarge form-control" value="<?= htmlspecialchars($d['harga']) ?>" type="text" readonly>

        <label class="control-label"><b>DP</b></label>
        <input name="dp" class="input-xxlarge form-control" value="<?= htmlspecialchars($d['dp']) ?>" type="text" readonly>

        <label class="control-label"><b>Sisa</b></label>
        <input name="sisa" class="input-xxlarge form-control" value="<?= htmlspecialchars($d['sisa']) ?>" type="text">
    </div>
</form>
