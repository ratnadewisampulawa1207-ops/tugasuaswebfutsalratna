<?php
session_start();
include("../db/config.php");

if (isset($_POST['submit'])) {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($conn && $username != '' && $password != '') {
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $datauser = $result->fetch_assoc();

            if (md5($password) === $datauser['password']) { 
                $_SESSION['username'] = $username;
                $_SESSION['nama'] = $datauser['nama'];
                $_SESSION['email'] = $datauser['email'];
                $_SESSION['id_admin'] = $datauser['id_admin'];
                header("Location: index.php");
                exit();
            } else {
                header("Location: login.php?err=yes");
                exit();
            }
        } else {
            header("Location: login.php?err=yes");
            exit();
        }
    } else {
        die("Koneksi database tidak tersedia atau input kosong!");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Login Admin - Futsal Booking</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Bootstrap & Font Awesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
    font-family: 'Rajdhani', sans-serif;
}
.login-container {
    max-width: 420px;
    margin: 80px auto;
    padding: 25px;
    background: rgba(0,0,0,0.85);
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.5);
    color: #fff;
    animation: fadeIn 0.8s ease-in-out;
}
.login-container h1 {
    text-align: center;
    margin-bottom: 20px;
    color: #00ff7f;
}
.form-control {
    background: rgba(255,255,255,0.1);
    border: none;
    color: #fff;
}
.form-control:focus {
    box-shadow: 0 0 10px #00ff7f;
    background: rgba(255,255,255,0.15);
}
.btn-login {
    background: #00ff7f;
    border: none;
    color: #000;
    font-weight: bold;
    transition: 0.3s;
}
.btn-login:hover {
    background: #00cc66;
}
.login-footer {
    text-align: center;
    margin-top: 15px;
}
.login-footer a {
    color: #00ff7f;
    text-decoration: none;
}
.login-footer a:hover {
    text-decoration: underline;
}
@keyframes fadeIn {
    from {opacity: 0; transform: translateY(-20px);}
    to {opacity: 1; transform: translateY(0);}
}
</style>
</head>
<body>

<div class="login-container">
    <h1><i class="fa-solid fa-futbol"></i> Admin Futsal</h1>
    <?php if(!empty($_GET['err'])){ ?>		
    <div class="alert alert-danger text-center">
        <i class="fa fa-exclamation-triangle"></i> Username atau password salah!
    </div>
    <?php } ?>
    <form method="post" action="">
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
        </div>
        <button type="submit" name="submit" class="btn btn-login w-100">Login</button>
    </form>
    <div class="login-footer">
        <p><a href="../index.php"><i class="fa fa-home"></i> Kembali ke beranda</a></p>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
