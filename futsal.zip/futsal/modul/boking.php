<?php 
defined("VALIDASI") or die("Tidak Diperkenankan Mengakses Data Secara Langsung !");
if (empty($_SESSION['usernamepengunjung']) && empty($_SESSION['namapengunjung'])) {
    echo "<script type='text/javascript'>  
    alert('Anda Belum Login :) , Silahkan Login terlebih dahulu');  
    window.location = 'login.php';  
    </script>";
    exit;
}
?>

<script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
<link rel="stylesheet" type="text/css" href="http://code.jquery.com/ui/1.9.1/themes/base/jquery-ui.css">
<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
        "search": false,
        "paging": false,
        "ordering": false,
        "info": false
    });
});
function konfirmasi() {
    return confirm("Anda yakin akan menghapus data ?");
}
</script>

<style type="text/css">
  .cdz {
    cursor: not-allowed;
  }
</style>

<?php
function DateToIndo($date) {
    $BulanIndo = array("Januari", "Februari", "Maret",
               "April", "Mei", "Juni",
               "Juli", "Agustus", "September",
               "Oktober", "November", "Desember");
    $tahun = substr($date, 0, 4);
    $bulan = substr($date, 5, 2);
    $tgl   = substr($date, 8, 2);
    return $tgl . " " . $BulanIndo[(int)$bulan - 1] . " " . $tahun;
}
?>

<div class="main">
    <div class="main-inner">
        <div class="container">
          <div class="row">         
             <div class="span9">
                <legend><b>Pemesanan</b></legend>
                <form class="form-inline" action="" method="POST">
                    <div class="form-group">
                        <input type="text" class="input-large" data-beatpicker="true" name="tgl">
                        <input type="submit" class="btn btn-sm btn-primary" value="cari">
                    </div>
                </form>
                
                <?php
                echo "Boking pada tanggal ";
                if (empty($_POST['tgl'])) {
                    echo DateToIndo(date("Y-m-d"));
                } else {
                    echo DateToIndo($_POST['tgl']);
                }
                ?>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Jam</th>
                            <th>Harga</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $tanggal = mysqli_real_escape_string($conn, $_POST['tgl'] ?? date("Y-m-d"));
                        $a = mysqli_query($conn, "SELECT jadwal.id_jadwal, jadwal.jam, jadwal.jams, harga.harga, harga.id_harga 
                                                  FROM jadwal, harga 
                                                  WHERE jadwal.id_harga = harga.id_harga 
                                                  ORDER BY jadwal.id_jadwal ASC");

                        while ($b = mysqli_fetch_array($a)) {
                            $querys = "SELECT pemesanan.id_jadwal, pemesanan.status, pemesanan.tanggal, pemesanan.jam, jadwal.id_jadwal, jadwal.jams 
                                       FROM pemesanan, jadwal 
                                       WHERE tanggal = '$tanggal' 
                                       AND pemesanan.id_jadwal = jadwal.id_jadwal 
                                       AND pemesanan.id_jadwal = '{$b['id_jadwal']}'";
                            $result = mysqli_query($conn, $querys);
                            $z = mysqli_fetch_array($result);

                            // Pastikan $z adalah array
                            $status = $z['status'] ?? null;
                            $tanggalZ = $z['tanggal'] ?? null;
                            $idJadwalZ = $z['id_jadwal'] ?? null;
                        ?>
                        <tr>
                            <td><?php echo $b['jams']; ?></td>
                            <td><?php echo $b['harga']; ?></td>
                            <td>
                                <?php
                                if ($status === "Tertunda") {
                                ?>
                                    <form action="index.php?modul=proses" method="POST" style="margin: 0 0 -10px;">
                                        <input type="hidden" name="idharga" value="<?php echo $b['id_harga']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $b['id_jadwal']; ?>">
                                        <input type="hidden" name="tanggalz" value="<?php echo $tanggal; ?>">
                                        <input type="hidden" name="harga" value="<?php echo $b['harga']; ?>">
                                        <input type="hidden" name="jamz" value="<?php echo $b['jams']; ?>">
                                        <input type="submit" value="pesan" class="btn btn-warning">
                                    </form>
                                <?php
                                } elseif ($tanggalZ === $tanggal && $b['id_jadwal'] == $idJadwalZ) {
                                    echo "<button type='button' class='btn btn-danger cdz'>Booked</button>";
                                } else {
                                ?>
                                    <form action="index.php?modul=proses" method="POST" style="margin: 0 0 -10px;">
                                        <input type="hidden" name="idharga" value="<?php echo $b['id_harga']; ?>">
                                        <input type="hidden" name="id" value="<?php echo $b['id_jadwal']; ?>">
                                        <input type="hidden" name="tanggalz" value="<?php echo $tanggal; ?>">
                                        <input type="hidden" name="harga" value="<?php echo $b['harga']; ?>">
                                        <input type="hidden" name="jamz" value="<?php echo $b['jams']; ?>">
                                        <input type="submit" value="pesan" class="btn btn-primary">
                                    </form>
                                <?php
                                }
                                ?>
                            </td>
                        </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div><!--/span9-->
        </div><!--/row-->
    </div> <!--/container-->
</div> <!-- /main-inner -->
</div> <!--/ main-->

<script>
$(document).ready(function () {
    $('#datepicker').datepicker({ dateFormat: 'dd-mm-yy' });
});
</script>
