<?php
// Koneksi database (ubah sesuai settingan kamu)
$koneksi = mysqli_connect("localhost", "root", "", "futsal");
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Ambil data POST dengan tanda kutip dan fallback jika kosong
$a       = $_POST['id_laps'] ?? '';
$idharga = $_POST['idharga'] ?? '';
$iduser  = $_POST['iduser'] ?? '';
$b       = $_POST['username'] ?? '';
$c       = $_POST['nama_klub'] ?? '';
$d       = $_POST['tanggals'] ?? '';
$e       = $_POST['jams'] ?? '';
$f       = $_POST['harga'] ?? '';
$g       = $_POST['alamat'] ?? '';
$h       = $_POST['no_telpon'] ?? '';

// Escape data sebelum query untuk keamanan
$a_safe       = mysqli_real_escape_string($koneksi, $a);
$idharga_safe = mysqli_real_escape_string($koneksi, $idharga);
$iduser_safe  = mysqli_real_escape_string($koneksi, $iduser);
$b_safe       = mysqli_real_escape_string($koneksi, $b);
$c_safe       = mysqli_real_escape_string($koneksi, $c);
$d_safe       = mysqli_real_escape_string($koneksi, $d);
$e_safe       = mysqli_real_escape_string($koneksi, $e);
$f_safe       = mysqli_real_escape_string($koneksi, $f);
$g_safe       = mysqli_real_escape_string($koneksi, $g);
$h_safe       = mysqli_real_escape_string($koneksi, $h);

// Query insert ke database
$query = "INSERT INTO pemesanan 
(id_pelanggan, id_harga, id_jadwal, username, nama_klub, alamat, no_telpon, tanggal, jam, harga, status) 
VALUES 
('$iduser_safe', '$idharga_safe', '$a_safe', '$b_safe', '$c_safe', '$g_safe', '$h_safe', '$d_safe', '$e_safe', '$f_safe', 'Tertunda')";

if (mysqli_query($koneksi, $query)) {
    echo "<script>
        alert('Pemesanan sudah terkirim, silahkan melakukan pembayaran setengah jam sebelum main');
        window.location.href='index.php?modul=pesandetail';
    </script>";
} else {
    die("Error: " . mysqli_error($koneksi));
}
?>
