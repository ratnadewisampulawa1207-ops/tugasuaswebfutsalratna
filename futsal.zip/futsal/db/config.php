<?php
// Aktifkan error reporting sementara untuk debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi ke MySQL
$conn = mysqli_connect('localhost', 'root', '', 'futsal');
if (!$conn) {
    die('Gagal koneksi ke MySQL: ' . mysqli_connect_error());
}

// Ambil data profil
$result = mysqli_query($conn, "SELECT * FROM profil WHERE id_profil = '1'");
$zz = mysqli_fetch_array($result);

$namaprofil = $zz['namafutsal'] ?? 'Nama Futsal';
$alamatprofil = $zz['alamat'] ?? '';
$kodeposprofil = $zz['kodepos'] ?? '';
$faxprofil = $zz['fax'] ?? '';
$no_telponprofil = $zz['no_hp'] ?? '';

// Definisi validasi hanya jika belum didefinisikan
if (!defined('VALIDASI')) {
    define('VALIDASI', 1);
}

// Include_once fungsigambar.php supaya fungsi tidak dideklarasikan ulang
// Path diperbaiki: dari db/config.php ke admin/fungsigambar.php
include_once __DIR__ . "/../admin/fungsigambar.php";
?>
