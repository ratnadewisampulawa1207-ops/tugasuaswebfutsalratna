<style type="text/css">
	.btn-success{
		background-color: #2980b9 !important;
	}
</style>
<?php
session_start();

$_SESSION['KCFINDER'] = array();
$_SESSION['KCFINDER']['disabled'] = false;
$_SESSION['KCFINDER']['uploadURL'] = "/bkk/Images/";
$_SESSION['KCFINDER']['uploadDir'] = "";

// Pastikan koneksi sudah ada di config.php
// Contoh di config.php:
// $conn = mysqli_connect("localhost", "root", "", "nama_database") or die(mysqli_connect_error());

include("db/config.php");

if (!empty($_SESSION['usernamepesan']) && !empty($_SESSION['namapesan'])) {
	echo "<script type='text/javascript'>  
	alert('Anda Sudah Login :) , Silahkan Logout terlebih dahulu');  
	window.location = 'index.php';  
	</script>";
}

if (!empty($_POST['submit'])) {

	// Gunakan mysqli_query
	$username = mysqli_real_escape_string($conn, $_POST['username']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);

	$perintah_query = mysqli_query($conn, "SELECT * FROM pelanggan WHERE username='$username' AND password=MD5('$password')");

	if (mysqli_num_rows($perintah_query) > 0) {
		// SUKSES
		$datauser = mysqli_fetch_array($perintah_query);
		$_SESSION['usernamepengunjung'] = $username;
		$_SESSION['passpengunjung'] = $password;
		$_SESSION['namapengunjung'] = $datauser['nama'];

		header("Location: index.php");
		exit();
	} else {
		// GAGAL LOGIN
		header("Location: login.php?err=yes");
		exit();
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title>Aplikasi Reservasi lapangan Futsal</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/pages/signin.css" rel="stylesheet" type="text/css">

<style>
body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
    font-family: 'Rajdhani', sans-serif;
}
.login-container {
    max-width: 420px;
    margin: 80px auto;
    padding: 25px;
    background: rgba(0,0,0,0.85);
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.5);
    color: #fff;
    animation: fadeIn 0.8s ease-in-out;
}
.login-container h1 {
    text-align: center;
    margin-bottom: 20px;
    color: #00ff7f;
}
.form-control {
    background: rgba(255,255,255,0.1);
    border: none;
    color: #fff;
}
.form-control:focus {
    box-shadow: 0 0 10px #00ff7f;
    background: rgba(255,255,255,0.15);
}
.btn-login {
    background: #00ff7f;
    border: none;
    color: #000;
    font-weight: bold;
    transition: 0.3s;
}
.btn-login:hover {
    background: #00cc66;
}
.login-footer {
    text-align: center;
    margin-top: 15px;
}
.login-footer a {
    color: #00ff7f;
    text-decoration: none;
}
.login-footer a:hover {
    text-decoration: underline;
}
@keyframes fadeIn {
    from {opacity: 0; transform: translateY(-20px);}
    to {opacity: 1; transform: translateY(0);}
}
</style>

</head>

<body>
	
	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand">
					Login Area Pelanggan			
				</a>		
				<div class="nav-collapse">
					<ul class="nav pull-right">
						<li class="">						
							<a href="index.php" class="">
								<i class="icon-chevron-left"></i>
								Kembali
							</a>
						</li>
					</ul>
				</div><!--/.nav-collapse -->	
			</div> <!-- /container -->
		</div> <!-- /navbar-inner -->
	</div> <!-- /navbar -->

	<div class="account-container">
		<div class="content clearfix">
			<form action="" method="post">
				<h1>Login Pelanggan</h1>
				<?php if (!empty($_GET['err'])) { ?>		
				<div class="alert alert-danger" role="alert">
				  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
				  <span class="sr-only">Error:</span>
				  Enter a valid username and password
				</div>
				<?php } ?>
				<div class="login-fields">
					<p>Please provide your details</p>
					<div class="field">
						<label for="">Username:</label>
						<input type="username" name="username" placeholder="Username" class="login username-field" required />
					</div> <!-- /field -->
					<div class="field">
						<label for="password">Password:</label>
						<input type="password" id="password" name="password" placeholder="Password" class="login password-field" required/>
					</div> <!-- /password -->
				</div> <!-- /login-fields -->
				<div class="login-actions">
					<input type="submit" name="submit" value="Login" class="button btn btn-success btn-large">
				</div> <!-- .actions -->
				<div class="login-footer">
            <p>Login sebagai  <a href="admin/login.php"><i class="fa fa-user"></i> admin</a></p>
            <p><a href="index.php"><i class="fa fa-chevron-left"></i> Kembali ke Beranda</a></p>
        </div>
		</div> <!-- /content -->
	</div> <!-- /account-container -->

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/signin.js"></script>

</body>
</html>
