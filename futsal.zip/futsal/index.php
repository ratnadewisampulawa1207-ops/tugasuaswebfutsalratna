<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Cek koneksi database
include("db/config.php");
if (!isset($conn)) {
    die("Koneksi database gagal. Pastikan file db/config.php benar.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  
<meta charset="utf-8">
<title>Aplikasi Reservasi Lapangan Futsal</title>

<!-- jQuery -->
<script src="js/jquery-1.7.2.min.js"></script>

<!-- CKEditor -->
<script src="ckeditor/ckeditor.js"></script>
<link rel="stylesheet" href="ckeditor/content.css" type="text/css"/>
<script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>

<!-- Bootstrap -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">

<!-- BeatPicker -->
<script src="plug/BeatPicker.min.js"></script>
<link rel="stylesheet" href="plug/BeatPicker.min.css">

<!-- DataTables -->
<link rel="stylesheet" href="media/css/jquery.dataTables.css" type="text/css" />
<script src="media/js/jquery.dataTables.js"></script>
<script>
$(document).ready(function() {
    $('#datatables').DataTable({
        "scrollX": true,
        "oLanguage": {
            "sLengthMenu": "Tampilkan _MENU_ data per halaman",
            "sSearch": "Pencarian:",
            "sZeroRecords": "Maaf, tidak ada data yang ditemukan",
            "sInfo": "Menampilkan _START_ s/d _END_ dari _TOTAL_ data",
            "sInfoEmpty": "Menampilkan 0 s/d 0 dari 0 data",
            "sInfoFiltered": "(di filter dari _MAX_ total data)"
        }
    });
});
</script>
<style>
/* ================= BODY & BACKGROUND ================= */
body {
    font-family: 'Open Sans', sans-serif;
    background: url('images/futsal-bg.jpg') no-repeat center center fixed;
    background-size: cover;
    color: #2c3e50;
    margin: 0;
    padding: 0;
}

/* ================= NAVBAR ================= */
.navbar {
    background-color: rgba(44, 62, 80, 0.95) !important;
    border-bottom: 4px solid #e74c3c;
    box-shadow: 0px 4px 12px rgba(0,0,0,0.3);
}
.navbar .brand {
    color: #ecf0f1 !important;
    font-weight: 700;
    font-size: 24px;
    letter-spacing: 1px;
}
.navbar .nav li a {
    color: #ecf0f1 !important;
    font-weight: 600;
    transition: color 0.3s;
}
.navbar .nav li a:hover {
    color: #f1c40f !important;
}

/* ================= SUBNAVBAR ================= */
.subnavbar {
    background-color: #34495e;
    border-top: 3px solid #e74c3c;
    padding: 10px 0;
}
.subnavbar .container {
    display: flex;
    justify-content: center;
}

/* ================= MAIN CONTENT ================= */
.main {
    margin-top: 30px;
}
.main-inner {
    background: rgba(255,255,255,0.95);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0px 0px 25px rgba(0,0,0,0.3);
}

/* ================= WIDGET ================= */
.widget {
    background: #ecf0f1;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0px 4px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}
.widget:hover {
    transform: translateY(-5px);
}
.widget .widget-content {
    font-size: 16px;
    color: #2c3e50;
}

/* ================= TABLE ================= */
table.dataTable {
    width: 100% !important;
    border-collapse: collapse;
}
table.dataTable th, table.dataTable td {
    text-align: center;
    padding: 12px;
    border-bottom: 1px solid #bdc3c7;
}
table.dataTable th {
    background-color: #e74c3c;
    color: #fff;
}
table.dataTable tbody tr:hover {
    background-color: #f39c12;
    color: #fff;
}

/* ================= BUTTON ================= */
.btn {
    border-radius: 8px;
    padding: 10px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
}
.btn-primary {
    background-color: #e74c3c;
    border: none;
}
.btn-primary:hover {
    background-color: #c0392b;
    color: #fff;
}
.btn-success {
    background-color: #27ae60;
    border: none;
}
.btn-success:hover {
    background-color: #1e8449;
    color: #fff;
}

/* ================= FORMS ================= */
input, select, textarea {
    border-radius: 6px;
    border: 1px solid #bdc3c7;
    padding: 8px;
    transition: border 0.3s, box-shadow 0.3s;
}
input:focus, select:focus, textarea:focus {
    border-color: #e74c3c;
    box-shadow: 0 0 5px rgba(231,76,60,0.5);
}

/* ================= FOOTER ================= */
.application-footer {
    background-color: rgba(44, 62, 80, 0.95);
    color: #ecf0f1;
    padding: 25px 0;
    text-align: center;
    border-top: 4px solid #e74c3c;
}
.application-footer a {
    color: #f1c40f;
    text-decoration: none;
}
.application-footer a:hover {
    color: #e74c3c;
}

/* ================= HOVER & ANIMATION ================= */
a:hover {
    color: #f39c12 !important;
}
.widget, .btn, .navbar, .subnavbar {
    transition: all 0.3s ease;
}

/* ================= RESPONSIVE ================= */
@media (max-width: 768px) {
    .navbar .brand {
        font-size: 20px;
    }
    .widget .widget-content {
        font-size: 14px;
    }
}
</style>

</head>
<body>

<!-- Navbar -->
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container">
      <a class="brand" href="index.php">
        <?php 
        if (empty($_SESSION['namapengunjung'])){
          echo isset($namaprofil) ? $namaprofil : "Reservasi Futsal";
        } else { 
          echo "Pemesanan Lapangan Futsal";
        }
        ?>
      </a>
      <div class="nav-collapse">
        <?php if (!empty($_SESSION['namapengunjung'])): ?>
        <ul class="nav pull-right">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="icon-user"></i> 
              <?php echo htmlspecialchars($_SESSION['namapengunjung']); ?> 
              <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
              <li><a href="logout.php">Logout</a></li>
            </ul>
          </li>
        </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Subnavbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <?php include('menu.php'); ?>
    </div>
  </div>
</div>

<!-- Main content -->
<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
        <?php
        if (!empty($_GET['modul'])) {
            $file_modul = "modul/" . basename($_GET['modul']) . ".php";
            if (file_exists($file_modul)) {
                include($file_modul);
            } else {
                echo "<h2>Error! Halaman tidak ditemukan.</h2>";
            }
        } else {
        ?>
        <div class="col-md-9">
          <div class="widget">
            <div class="widget-content">
              SELAMAT DATANG ^_^ 
              <?php echo isset($_SESSION['namapengunjung']) ? htmlspecialchars($_SESSION['namapengunjung']) : ''; ?>
            </div>
          </div>
        </div>
        <?php include 'modul/menu_kanan.php'; ?>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<footer class="application-footer">
  <div class="container">
    <center>
      <p>Repost by Ratna Dewi  Sampulawa</p>
      <p><b>Aplikasi Reservasi Lapangan Futsal</b></p>
      <p>All rights reserved. &copy; <?php echo date("Y"); ?> <?php echo isset($namaprofil) ? $namaprofil : ""; ?></p>
    </center>
  </div>
</footer>

<!-- JS -->
<script src="js/excanvas.min.js"></script> 
<script src="js/chart.min.js"></script> 
<script src="js/bootstrap.js"></script>

</body>
</html>
